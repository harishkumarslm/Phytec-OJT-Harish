#!/bin/bash

for VAR in 1 2 3 4 5 a b c d
do
	echo $VAR
done
