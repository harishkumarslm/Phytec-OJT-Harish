#!/bin/bash

for i in {1..25}
do
	echo "Welcome $i times"
done
