double mysub(double a, double b){
   return a - b;
}
