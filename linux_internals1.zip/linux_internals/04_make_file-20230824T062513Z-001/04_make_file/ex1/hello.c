
#include <stdio.h>
int main(){
   printf("Welcome to Learning make utility.!\n");
   return 0;
}
