
double mydiv(double a, double b){
	if (b != 0)
   		return a / b;
	return 0;
}
