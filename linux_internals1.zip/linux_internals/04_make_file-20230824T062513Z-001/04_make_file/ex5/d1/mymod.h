int mymod(int,int);
