#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/rfcomm.h>
#include <MQTTClient.h>

#define BT_DEVICE_ADDRESS "XX:XX:XX:XX:XX:XX" // Replace with your Bluetooth device address
#define BT_PORT 1

int set_interface_attribs(int fd, int speed) {
    // ... (unchanged)

    return 0;
}

int establish_bluetooth_connection() {
    struct sockaddr_rc addr = { 0 };
    int s, status;

    s = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);
    addr.rc_family = AF_BLUETOOTH;
    addr.rc_channel = (uint8_t)BT_PORT;
    str2ba(BT_DEVICE_ADDRESS, &addr.rc_bdaddr);

    status = connect(s, (struct sockaddr*)&addr, sizeof(addr));
    if (status < 0) {
        perror("Error connecting to Bluetooth device");
        return -1;
    }

    return s;
}

void publish_to_mqtt(MQTTClient client, const char* topic, const char* payload) {
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    pubmsg.payload = (void*)payload;
    pubmsg.payloadlen = strlen(payload);
    pubmsg.qos = 1;
    pubmsg.retained = 0;

    MQTTClient_deliveryToken token;
    MQTTClient_publishMessage(client, topic, &pubmsg, &token);
    MQTTClient_waitForCompletion(client, token, TIMEOUT);
}

int main() {
    // ... (unchanged)

    int bt_fd = establish_bluetooth_connection();
    if (bt_fd < 0) {
        return -1;
    }

    MQTTClient client;
    MQTTClient_create(&client, "tcp://mqtt.broker.com:1883", "ClientID", MQTTCLIENT_PERSISTENCE_NONE, NULL);
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;

    if (MQTTClient_connect(client, &conn_opts) != MQTTCLIENT_SUCCESS) {
        printf("Failed to connect to MQTT server\n");
        return -1;
    }

    // Write CMD?ADDR\r\n command
    printf("%s", arr1);
    wlen = write(bt_fd, arr1, sizeof(arr1) - 1);
    sleep(3);

    while (1) {
        // Read data from the Bluetooth module
        rdlen = read(bt_fd, buf, sizeof(buf) - 1);
        if (rdlen > 0) {
            buf[rdlen] = '\0';
            printf("Received data: %s\n", buf);

            // Publish data to MQTT server
            publish_to_mqtt(client, "mqtt/topic", buf);
        }
    }

    MQTTClient_disconnect(client, 10000);
    MQTTClient_destroy(&client);

    close(bt_fd);
    return 0;
}

