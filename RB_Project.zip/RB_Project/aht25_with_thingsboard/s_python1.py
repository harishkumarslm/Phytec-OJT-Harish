import paho.mqtt.client as paho
import json
import time

ACCESS_TOKEN = '4Iq0PdNohIDjA9cZSyhH'  # Token of your device
broker = "phyclouds.com"  # host name
port = 1884  # data listening port

def on_publish(client, userdata, result):  # create function for callback
    print("Data published to ThingsBoard\n")

client1 = paho.Client("iiscSmartSwitch")  # create client object
client1.on_publish = on_publish  # assign function to callback
client1.username_pw_set(ACCESS_TOKEN)  # access token from ThingsBoard device
client1.connect(broker, port, keepalive=60)  # establish connection

while True:
    payload = {"Humidity": 100, "Temperature": 30}
    payload_str = json.dumps(payload)  # Convert payload to JSON string
    ret = client1.publish("v1/devices/me/telemetry", payload_str)  # topic - v1/devices/me/telemetry
    print("Please check LATEST TELEMETRY field of your device")
    print(payload)
    time.sleep(7)

