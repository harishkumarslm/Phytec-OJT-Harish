#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#define GPIO_ECHO "/sys/class/gpio/gpio12/value"
#define GPIO_TRIGGER "/sys/class/gpio/gpio13/value"

int echo_fd, trigger_fd;

void setup() {
    // Export GPIO pins
    int export_fd = open("/sys/class/gpio/export", O_WRONLY);
    write(export_fd, "12", 2);  // Echo pin
    write(export_fd, "13", 2);  // Trigger pin
    close(export_fd);

    // Set GPIO directions
    echo_fd = open("/sys/class/gpio/gpio12/direction", O_WRONLY);
    write(echo_fd, "in", 2);
    close(echo_fd);
    trigger_fd = open("/sys/class/gpio/gpio13/direction", O_WRONLY);
    write(trigger_fd, "out", 3);
    close(trigger_fd);
}

void cleanup() {
    // Unexport GPIO pins
    int unexport_fd = open("/sys/class/gpio/unexport", O_WRONLY);
    write(unexport_fd, "12", 2);
    write(unexport_fd, "13", 2);
    close(unexport_fd);
}

void loop() {
    char buffer[2];  // Declare buffer
    while (1) {

        // Trigger pulse
        trigger_fd = open(GPIO_TRIGGER, O_WRONLY);
        write(trigger_fd, "1", 1);
        close(trigger_fd);
        usleep(10);
        trigger_fd = open(GPIO_TRIGGER, O_WRONLY);
        write(trigger_fd, "0", 1);
        close(trigger_fd);

        // Wait for echo response
        echo_fd = open(GPIO_ECHO, O_RDONLY);
        while (read(echo_fd, buffer, 1) && buffer[0] == '0');
        close(echo_fd);

        struct timeval start_time, end_time;
        gettimeofday(&start_time, NULL);

        echo_fd = open(GPIO_ECHO, O_RDONLY);
        while (read(echo_fd, buffer, 1) && buffer[0] == '1');
        close(echo_fd);

        gettimeofday(&end_time, NULL);

        // Calculate distance
        double elapsed_time = (end_time.tv_sec - start_time.tv_sec) * 1000000.0 +
                              (end_time.tv_usec - start_time.tv_sec);
        int distance = elapsed_time * 0.0343 / 2.0;  // Speed of sound is approximately 343 meters/second

        printf("Echo1: %u Dis1: %.2f cm\r\n", (unsigned int)elapsed_time, distance);
        usleep(500000);  // Delay for stable readings
    }
}

int main() {
    // Setup GPIO
    setup();

    // Run the main loop
    loop();

    // Cleanup GPIO
    cleanup();
    return 0;
}

