#include <stdio.h>
#include <stdlib.h>
#include <mraa.h>
#include <stdint.h>
#include <math.h>
#include <signal.h>
#include <unistd.h>
/* mraa header */
#include "mraa/i2c.h"

#define I2C_BUS 1
#define AHT25_ADDR 0x38 // Address of the AHT25 sensor
#define AHT25_INIT_CMD 0xE1
#define AHT25_MEASURE_CMD 0xAC

mraa_result_t status = MRAA_SUCCESS;
mraa_i2c_context i2c;


int i2c_init(void)
{
	i2c = mraa_i2c_init(I2C_BUS);
	if (i2c == NULL) {
        	fprintf(stderr, "Failed to initialize I2C\n");
        	mraa_deinit();
        	return EXIT_FAILURE;
    	}	
    
    
	/* set slave address */
    	status = mraa_i2c_address(i2c, AHT25_ADDR );
    	if (status != MRAA_SUCCESS) {
        	return EXIT_FAILURE;
    	}
 }  
 
// Function to set up GPIO pins
void setup() {
    // Initialize MRAA
    mraa_init();

    // Initialize I2C
    mraa_i2c_context i2c = mraa_i2c_init(1); // Use I2C bus 1

    // Set the I2C slave address
    if (mraa_i2c_address(i2c, AHT25_ADDR) != MRAA_SUCCESS) {
        fprintf(stderr, "Error setting I2C slave address\n");
        mraa_i2c_stop(i2c);
        mraa_deinit();
        exit(EXIT_FAILURE);
    }

    // Transmit initialization command
    if (mraa_i2c_write_byte(i2c, AHT25_INIT_CMD) != MRAA_SUCCESS) {
        fprintf(stderr, "Error writing to I2C device\n");
        mraa_i2c_stop(i2c);
        mraa_deinit();
        exit(EXIT_FAILURE);
    }

    // Close I2C
    mraa_i2c_stop(i2c);
}

// Function to read sensor values
void read_sensor_values(mraa_i2c_context i2c, float *temperature, float *humidity) {
    uint8_t data[6];
    uint8_t cmd = AHT25_MEASURE_CMD;

    // Transmit command to the sensor
    if (mraa_i2c_write_byte(i2c, cmd) != MRAA_SUCCESS) {
        fprintf(stderr, "Error writing to I2C device\n");
        mraa_i2c_stop(i2c);
        mraa_deinit();
        exit(EXIT_FAILURE);
    }

    usleep(100000); // Delay for measurement

    // Receive data from the sensor
    if (mraa_i2c_read(i2c, data, sizeof(data)) != sizeof(data)) {
        fprintf(stderr, "Error reading from I2C device\n");
        mraa_i2c_stop(i2c);
        mraa_deinit();
        exit(EXIT_FAILURE);
    }

    *humidity = ((float)((data[1] << 12) | (data[2] << 4) | (data[3] >> 4))) / 1048576.0 * 100.0;
    *temperature = ((float)(((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5])) / 1048576.0 * 200.0 - 50.0;
}

int main(int argc, char *argv[]) {
    // Set up GPIO pins
    setup();
    
    i2c_init();
    // Initialize I2C
    mraa_i2c_context i2c = mraa_i2c_init(1); // Use I2C bus 1

    // Set the I2C slave address
    if (mraa_i2c_address(i2c, AHT25_ADDR) != MRAA_SUCCESS) {
        fprintf(stderr, "Error setting I2C slave address\n");
        mraa_i2c_stop(i2c);
        mraa_deinit();
        exit(EXIT_FAILURE);
    }

    float temperature, humidity;

    // Read sensor values
    read_sensor_values(i2c, &temperature, &humidity);

    // Print temperature and humidity
    printf("Temperature: %.2f°C\n", temperature);
    printf("Humidity: %.2f%%\n", humidity);

    // Close I2C
    mraa_i2c_stop(i2c);

    // Cleanup MRAA
    mraa_deinit();

    // Continue with the rest of your program logic

    return 0;
}

