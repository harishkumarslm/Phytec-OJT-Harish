#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mosquitto.h>
#include <unistd.h>

#define ACCESS_TOKEN "4Iq0PdNohIDjA9cZSyhH"
#define BROKER_ADDRESS "phyclouds.com"
#define BROKER_PORT  1884
#define CLIENT_ID "e791a4f0-ab96-11ee-ae74-db5ae19db63f"
#define TOPIC "v1/devices/me/telemetry"

struct mosquitto *mosq = NULL;

void on_connect(struct mosquitto *mosq, void *userdata, int rc) {
    if (rc == MOSQ_ERR_SUCCESS) {
        printf("Connected to broker\n");
        // Subscribe to the telemetry topic after successful connection
        mosquitto_subscribe(mosq, NULL, TOPIC, 0);
    } else {
        fprintf(stderr, "Failed to connect to broker: %s\n", mosquitto_connack_string(rc));
    }
}

void on_publish(struct mosquitto *mosq, void *userdata, int mid) {
    printf("Message %d published to ThingsBoard\n", mid);
}

void on_subscribe(struct mosquitto *mosq, void *userdata, int mid, int qos_count, const int *granted_qos) {
    printf("Subscribed to topic with QoS: %d\n", granted_qos[0]);
}

void on_message(struct mosquitto *mosq, void *userdata, const struct mosquitto_message *message) {
    printf("Received message for topic %s: %s\n", message->topic, (char *)message->payload);
}

int main() {
    mosquitto_lib_init();

    mosq = mosquitto_new(CLIENT_ID, true, NULL);
    if (!mosq) {
        fprintf(stderr, "Error: Out of memory.\n");
        return 1;
    }

    mosquitto_connect_callback_set(mosq, on_connect);
    mosquitto_publish_callback_set(mosq, on_publish);
    mosquitto_subscribe_callback_set(mosq, on_subscribe);
    mosquitto_message_callback_set(mosq, on_message);

    mosquitto_username_pw_set(mosq, NULL, ACCESS_TOKEN);

    if (mosquitto_connect(mosq, BROKER_ADDRESS, BROKER_PORT, 60) != MOSQ_ERR_SUCCESS) {
        fprintf(stderr, "Unable to connect to the broker.\n");
        perror("Error");
        mosquitto_destroy(mosq);
        mosquitto_lib_cleanup();
        return 1;
    }

    mosquitto_loop_start(mosq);

    while (true) {
        char payload[100];
        snprintf(payload, sizeof(payload), "{\"Humidity\":%d, \"Temperature\":%d}", 100, 30);

        int mid;
        if (mosquitto_pub(mosq, &mid, TOPIC, strlen(payload), payload, 0, false) != MOSQ_ERR_SUCCESS) {
            fprintf(stderr, "Failed to publish message.\n");
            perror("Error");
        }

        printf("Please check LATEST TELEMETRY field of your device\n");
        printf("%s\n", payload);

        sleep(7);
    }

    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();

    return 0;
}


