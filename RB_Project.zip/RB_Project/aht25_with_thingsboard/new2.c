#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>
#include <stdint.h>  // Include this header for uint8_t type
#include <sys/ioctl.h>
#include <linux/i2c-dev.h>

#include "MQTTClient.h"

#define I2C_DEVICE_PATH "/dev/i2c-0"  // Adjust according to your system
#define AHT25_ADDR 0x38
#define I2C_BUS 0

#define AHT25_INIT_CMD 0xE1
#define AHT25_MEASURE_CMD 0xAC

#define UART_DEVICE_PATH "/dev/ttyS0"  // Adjust according to your system
// MQTT Settings
#define ACCESS_TOKEN "4Iq0PdNohIDjA9cZSyhH"
#define MQTT_ADDRESS "tcp://phyclouds.com:1884"
#define MQTT_CLIENTID "iiscSmartSwitch"
#define MQTT_TOPIC "v1/devices/me/telemetry"
#define MQTT_QOS 1

// Global MQTT client variable
MQTTClient client;
MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;

void write_i2c_register(int i2c_fd, uint8_t reg, uint8_t value) {
    unsigned char data[2];
    data[0] = reg;
    data[1] = value;
    if (write(i2c_fd, data, 2) != 2) {
        perror("Error writing to I2C device");
        exit(EXIT_FAILURE);
    }
}

void read_i2c_bytes(int i2c_fd, uint8_t reg, uint8_t *data, int len) {
    if (write(i2c_fd, &reg, 1) != 1) {
        perror("Error writing to I2C device");
        exit(EXIT_FAILURE);
    }

    if (read(i2c_fd, data, len) != len) {
        perror("Error reading from I2C device");
        exit(EXIT_FAILURE);
    }
}

void read_sensor_values(float *temperature, float *humidity) {
    int i2c_fd = open(I2C_DEVICE_PATH, O_RDWR);
    if (i2c_fd == -1) {
        perror("Error opening I2C device");
        exit(EXIT_FAILURE);
    }

    if (ioctl(i2c_fd, I2C_SLAVE, AHT25_ADDR) == -1) {
        perror("Error setting I2C slave address");
        exit(EXIT_FAILURE);
    }

    write_i2c_register(i2c_fd, AHT25_MEASURE_CMD, 0);

    usleep(1000);

    uint8_t data[6];
    read_i2c_bytes(i2c_fd, 0x00, data, 6);

    *humidity = ((float)((data[1] << 12) | (data[2] << 4) | (data[3] >> 4))) / 1048576.0 * 100.0;
    *temperature = ((float)(((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5])) / 1048576.0 * 200.0 - 50.0;

    close(i2c_fd);
}

void write_uart(const char *data) {
    int uart_fd = open(UART_DEVICE_PATH, O_WRONLY);
    if (uart_fd == -1) {
        perror("Error opening UART device");
        exit(EXIT_FAILURE);
    }

    if (write(uart_fd, data, strlen(data)) != strlen(data)) {
        perror("Error writing to UART device");
        exit(EXIT_FAILURE);
    }

    close(uart_fd);
}

// Function to publish data to MQTT
void publishToMQTT(char *topic, char *payload) {
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    pubmsg.payload = payload;
    pubmsg.payloadlen = strlen(payload);
    pubmsg.qos = 1;
    pubmsg.retained = 0;
    MQTTClient_deliveryToken token;

    MQTTClient_publishMessage(client, topic, &pubmsg, &token);
    MQTTClient_waitForCompletion(client, token, 1000);

    int rc = MQTTClient_waitForCompletion(client, token, 10000);

    if (rc == MQTTCLIENT_SUCCESS) {
        // Print information about the published data
        printf("Published MQTT data - Topic: %s, Payload: %s\n", topic, payload);
    } else {
        fprintf(stderr, "Failed to publish file data. Return code: %d\n", rc);
    }
}



int main() {
   
    // MQTT initialization
    MQTTClient_create(&client, MQTT_ADDRESS, MQTT_CLIENTID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;
    conn_opts.username = ACCESS_TOKEN;

    if (MQTTClient_connect(client, &conn_opts) != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to connect to MQTT server\n");
        close(i2c_fd);
        return -1;
    }

    while (1) {
        // Read sensor data
        float humidity, temperature;
        read_sensor_values(&temperature, &humidity);
        
        char uart_data[50];
        snprintf(uart_data, sizeof(uart_data), "Temperature=%.2f\r\n", temperature);
        write_uart(uart_data);

        usleep(10000);

        snprintf(uart_data, sizeof(uart_data), "Humidity=%.2f\r\n", humidity);
        write_uart(uart_data);

        usleep(10000);
        
        // Convert sensor data to JSON string
        char mqtt_payload[500];
        snprintf(mqtt_payload, sizeof(mqtt_payload), "{\"Humidity\": %.2f, \"Temperature\": %.2f}", humidity, temperature);

        // Publish data to MQTT
        publishToMQTT(MQTT_TOPIC, mqtt_payload);

        // Print whether data is being published or not
        printf("Data %s published to MQTT\n", mqtt_payload);

        // Sleep for 7 seconds
        sleep(7);
    }

    // Cleanup MQTT resources
    MQTTClient_destroy(&client);
    close(i2c_fd);

    return 0;
}

