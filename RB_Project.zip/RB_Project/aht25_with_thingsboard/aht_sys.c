#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>  // Add this line for uint8_t type
#include <sys/ioctl.h>  // Add this line for ioctl function
#include <linux/i2c-dev.h>  // Add this line for I2C_SLAVE constant

#define AHT25_ADDR 0x38 // Address of the AHT25 sensor
#define I2C_BUS "/dev/i2c-0"

#define AHT25_INIT_CMD 0xE1
#define AHT25_MEASURE_CMD 0xAC

int i2c_fd;

void write_i2c_register(uint8_t reg, uint8_t value) {
    uint8_t buf[2];
    buf[0] = reg;
    buf[1] = value;
    write(i2c_fd, buf, 2);
}

void read_i2c_registers(uint8_t reg, uint8_t *data, int length) {
    write(i2c_fd, &reg, 1);
    read(i2c_fd, data, length);
}

void read_sensor_values(float *temperature, float *humidity) {
    uint8_t data[6];
    uint8_t cmd = AHT25_MEASURE_CMD;

    write_i2c_register(0x00, cmd);

    // Delay for measurement
    usleep(1000);  // Delay for 100 milliseconds

    read_i2c_registers(0x00, data, 6);

    *humidity = ((float)((data[1] << 12) | (data[2] << 4) | (data[3] >> 4))) / 1048576.0 * 100.0;
    *temperature = ((float)(((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5])) / 1048576.0 * 200.0 - 50.0;
}

int main() {
    char buffer[128];
    float temperature, humidity;

    // Initialize I2C
    i2c_fd = open(I2C_BUS, O_RDWR);
    if (i2c_fd < 0) {
        perror("Error opening I2C bus");
        exit(1);
    }

    if (ioctl(i2c_fd, I2C_SLAVE, AHT25_ADDR) < 0) {
        perror("Error setting I2C address");
        close(i2c_fd);
        exit(1);
    }

    write_i2c_register(0x00, AHT25_INIT_CMD);

    while (1) {
        read_sensor_values(&temperature, &humidity);

        printf("Temperature=%.2f\r\n", temperature);
        usleep(1000000);
        printf("Humidity=%.2f\r\n", humidity);
        usleep(1000000);
    }

    close(i2c_fd);

    return 0;
}

