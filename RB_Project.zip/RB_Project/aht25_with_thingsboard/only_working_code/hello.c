#include<stdio.h>
int main()
{
	printf("hi hello");
}

