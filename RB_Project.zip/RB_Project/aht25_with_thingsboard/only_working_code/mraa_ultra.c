#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "mraa/gpio.h"

#define TRIGGER_PIN "/sys/class/gpio/PA13/value" // Replace with the actual GPIO pin for trigger
#define ECHO_PIN "/sys/class/gpio/PA12/value"    // Replace with the actual GPIO pin for echo

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

long long micros()
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    return ts.tv_sec * 1000000LL + ts.tv_nsec / 1000LL;
}

int readDigitalValue(const char *pin)
{
    FILE *fp = fopen(pin, "r");
    if (fp == NULL)
    {
        error("Error opening digital pin");
    }

    char value;
    fscanf(fp, " %c", &value); // Leading space to skip any leading whitespace
    fclose(fp);

    // '1' indicates the presence of a signal (tilted), '0' indicates no signal)
    return (value == '1');
}

float readUltrasonicDistance()
{
    // Activate the trigger pin (PA13)
    FILE *triggerFile = fopen(TRIGGER_PIN, "w");
    if (triggerFile == NULL)
    {
        error("Error opening trigger GPIO pin");
    }

    fprintf(triggerFile, "1");
    fclose(triggerFile);

    usleep(10); // Sleep for a short duration to trigger the ultrasonic sensor

    // Deactivate the trigger pin (PA13)
    triggerFile = fopen(TRIGGER_PIN, "w");
    if (triggerFile == NULL)
    {
        error("Error opening trigger GPIO pin");
    }

    fprintf(triggerFile, "0");
    fclose(triggerFile);

    // Wait for the echo pin (PA12) to go high
    while (!readDigitalValue(ECHO_PIN))
        ;

    long startTime = micros();

    // Wait for the echo pin (PA12) to go low
    while (readDigitalValue(ECHO_PIN))
        ;

    long travelTime = micros() - startTime;

    // Calculate distance in centimeters
    float distance = (float)travelTime * 0.0343 / 2.0; // Speed of sound is approximately 343 meters/second

    return distance;
}

int main()
{
    // Assuming GPIO pins are not exported, you might need to export them first
    FILE *exportTrigger = fopen("/sys/class/gpio/export", "w");
    if (exportTrigger == NULL)
    {
        error("Error exporting trigger GPIO pin");
    }

    fprintf(exportTrigger, "13"); // Exporting trigger GPIO pin (PA13)
    fclose(exportTrigger);

    FILE *exportEcho = fopen("/sys/class/gpio/export", "w");
    if (exportEcho == NULL)
    {
        error("Error exporting echo GPIO pin");
    }

    fprintf(exportEcho, "12"); // Exporting echo GPIO pin (PA12)
    fclose(exportEcho);

    // Set the GPIO pins direction to in (for reading)
    FILE *directionTrigger = fopen("/sys/class/gpio/PA13/direction", "w");
    if (directionTrigger == NULL)
    {
        error("Error setting direction for trigger GPIO pin");
    }

    fprintf(directionTrigger, "out"); // Setting trigger GPIO pin (PA13) as output
    fclose(directionTrigger);

    FILE *directionEcho = fopen("/sys/class/gpio/PA12/direction", "w");
    if (directionEcho == NULL)
    {
        error("Error setting direction for echo GPIO pin");
    }

    fprintf(directionEcho, "in"); // Setting echo GPIO pin (PA12) as input
    fclose(directionEcho);

    while (1)
    {
        // Read the object distance using the ultrasonic sensor
        float distance = readUltrasonicDistance();

        printf("Object Distance: %.2f cm\n", distance);

        // Adjust the sleep duration based on your sensor's update rate
        sleep(1); // Sleep for 1 second between readings
    }

    // Unexport GPIO pins before exiting
    FILE *unexportTrigger = fopen("/sys/class/gpio/unexport", "w");
    if (unexportTrigger == NULL)
    {
        error("Error unexporting trigger GPIO pin");
    }

    fprintf(unexportTrigger, "13"); // Unexporting trigger GPIO pin (PA13)
    fclose(unexportTrigger);

    FILE *unexportEcho = fopen("/sys/class/gpio/unexport", "w");
    if (unexportEcho == NULL)
    {
        error("Error unexporting echo GPIO pin");
    }

    fprintf(unexportEcho, "12"); // Unexporting echo GPIO pin (PA12)
    fclose(unexportEcho);

    return 0;
}
