#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>
#include "MQTTClient.h"

// MQTT Settings
#define ACCESS_TOKEN "5RBiOmEg6aDyqZhDR7A3"  
#define MQTT_ADDRESS "tcp://phyclouds.com:1884"  
#define MQTT_CLIENTID "GPSData"
#define MQTT_TOPIC "gps/telemetry"
#define MQTT_QOS 1
// Global MQTT client variable
MQTTClient client;
MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;

// Publish data to MQTT
char mqtt_topic[200];  
char mqtt_payload[500]; 

struct GPSData
{
    double latitude;
    double longitude;
    int satellites_used;
    int mode;
};

// Function to publish data to MQTT
void publishToMQTT(char *topic, char *payload) {
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    pubmsg.payload = payload;
    pubmsg.payloadlen = strlen(payload);
    pubmsg.qos = 1;
    pubmsg.retained = 0;
    MQTTClient_deliveryToken token;

    MQTTClient_publishMessage(client, topic, &pubmsg, &token);
    MQTTClient_waitForCompletion(client, token, 1000);

    int rc = MQTTClient_waitForCompletion(client, token, 10000);

    if (rc == MQTTCLIENT_SUCCESS) {
        // Print information about the published data
        printf("Published MQTT data - Topic: %s, Payload: %s\n", topic, payload);
    } else {
        fprintf(stderr, "Failed to publish file data. Return code: %d\n", rc);
    }
}

// Function to check if a double value is finite
int is_finite(double value)
{
    return (value == value) && ((value - value) == 0);
}

void extract_lat_lon(const char *sentence, struct GPSData *gpsdata)
{
    char sentence_type[20];
    double latitude, longitude;

    if (sscanf(sentence, "$%6[^,],", sentence_type) != 1)
    {
        //fprintf(stderr, "Error parsing sentence type\n");
        return;
    }

    if (strncmp(sentence_type, "GPRMC", 6) == 0)
    {
        char lat_direction, lon_direction;
        if (sscanf(sentence, "$GPRMC,%*f,%*c,%lf,%c,%lf,%c", &latitude, &lat_direction, &longitude, &lon_direction) != 4)
        {
            fprintf(stderr, "Error extracting latitude and longitude from GPRMC sentence\n");
            return;
        }

        gpsdata->latitude = floor(latitude / 100) + (fmod(latitude, 100) / 60.0);
        gpsdata->latitude *= (lat_direction == 'S' || lat_direction == 's') ? -1 : 1;

        gpsdata->longitude = floor(longitude / 100) + (fmod(longitude, 100) / 60.0);
        gpsdata->longitude *= (lon_direction == 'W' || lon_direction == 'w') ? -1 : 1;
    }
    
    else if (strncmp(sentence_type, "GPGGA", 6) == 0)
    {
        char lat_direction, lon_direction;
        if (sscanf(sentence, "$GPGGA,%*f,%lf,%c,%lf,%c,", &latitude, &lat_direction, &longitude, &lon_direction) != 4)
        {
            fprintf(stderr, "Error extracting latitude and longitude from GPGGA sentence\n");
            return;
        }

        gpsdata->latitude = floor(latitude / 100) + (fmod(latitude, 100) / 60.0);
        gpsdata->latitude *= (lat_direction == 'S' || lat_direction == 's') ? -1 : 1;

        gpsdata->longitude = floor(longitude / 100) + (fmod(longitude, 100) / 60.0);
        gpsdata->longitude *= (lon_direction == 'W' || lon_direction == 'w') ? -1 : 1;
    }
}

int main()
{
    // MQTT initialization
    MQTTClient_create(&client, MQTT_ADDRESS, MQTT_CLIENTID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;
    conn_opts.username = ACCESS_TOKEN;
    
    if (MQTTClient_connect(client, &conn_opts) != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to connect to MQTT server\n");
        return -1;
    }

    const char *serial_port = "/dev/ttyUSB1";

    int serial_fd = open(serial_port, O_RDWR | O_NOCTTY);
    if (serial_fd < 0)
    {
        perror("Error opening serial port");
        return 1;
    }

    struct termios tty;
    memset(&tty, 0, sizeof(struct termios));

    if (tcgetattr(serial_fd, &tty) != 0)
    {
        perror("Error from tcgetattr");
        return 1;
    }

    cfsetospeed(&tty, B115200);
    cfsetispeed(&tty, B115200);

    tty.c_cflag &= ~PARENB;
    tty.c_cflag &= ~CSTOPB;
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;
    tty.c_cflag &= ~CRTSCTS;
    tty.c_cflag |= CREAD | CLOCAL;

    tty.c_iflag &= ~(IGNBRK | BRKINT | ICRNL | INLCR | PARMRK | INPCK | ISTRIP | IXON);
    tty.c_oflag = 0;
    tty.c_lflag &= ~(ECHO | ECHONL | ICANON | IEXTEN | ISIG);

    tty.c_cc[VMIN] = 1;
    tty.c_cc[VTIME] = 0;

    if (tcsetattr(serial_fd, TCSANOW, &tty) != 0)
    {
        perror("Error from tcsetattr");
        return 1;
    }

    char buffer[256];
    struct GPSData gpsdata;

    while (1)
    {
        ssize_t read_len = read(serial_fd, buffer, sizeof(buffer) - 1);
        if (read_len > 0)
        {
            buffer[read_len] = '\0'; // Null-terminate the received data
            extract_lat_lon(buffer, &gpsdata);

            // Check if latitude and longitude are available
            if (is_finite(gpsdata.latitude) && is_finite(gpsdata.longitude))
            {
                snprintf(mqtt_topic, sizeof(mqtt_topic), "gps/telemetry");
                snprintf(mqtt_payload, sizeof(mqtt_payload), "{\"[GPS DATA] Latitude, Longitude =\":\"%lf %lf\"}", gpsdata.latitude, gpsdata.longitude);
                  
                 // snprintf(mqtt_payload, sizeof(mqtt_payload), "{\"Latitude\": %lf}", gpsdata.latitude);
                //  snprintf(mqtt_topic, sizeof(mqtt_topic), "gps/telemetry");

		 // snprintf(mqtt_payload, sizeof(mqtt_payload), "{\"Longitude\": %lf}", gpsdata.longitude);

                // Publish data to MQTT
                publishToMQTT(mqtt_topic, mqtt_payload);

                // Print whether data is being published or not
                printf("Data %s published to MQTT\n", mqtt_payload);
            }
        }
    }

    close(serial_fd);

    // Cleanup MQTT resources
    MQTTClient_destroy(&client);

    return 0;
}
