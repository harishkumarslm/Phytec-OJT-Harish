#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <math.h>
#include "MQTTClient.h"
#include "mraa/i2c.h"
#include "mraa/uart.h"
#include <signal.h>

// MQTT Settings
#define ACCESS_TOKEN "4Iq0PdNohIDjA9cZSyhH"
#define MQTT_ADDRESS "tcp://phyclouds.com:1884"
#define MQTT_CLIENTID "iiscSmartSwitch"
#define MQTT_TOPIC "v1/devices/me/telemetry"
#define MQTT_QOS 1

// Global MQTT client variable
MQTTClient client;
MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;

// I2C and UART Initialization
mraa_i2c_context i2c;
mraa_uart_context uart;

// AHT25 Sensor Constants
#define AHT25_ADDR 0x38 // Address of the AHT25 sensor
#define AHT25_INIT_CMD 0xE1
#define AHT25_MEASURE_CMD 0xAC

// Function to publish data to MQTT
void publishToMQTT(char *topic, char *payload)
{
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    pubmsg.payload = payload;
    pubmsg.payloadlen = strlen(payload);
    pubmsg.qos = 1;
    pubmsg.retained = 0;
    MQTTClient_deliveryToken token;

    MQTTClient_publishMessage(client, topic, &pubmsg, &token);
    MQTTClient_waitForCompletion(client, token, 1000);

    int rc = MQTTClient_waitForCompletion(client, token, 10000);

    if (rc == MQTTCLIENT_SUCCESS)
    {
        // Print information about the published data
        printf("Published MQTT data - Topic: %s, Payload: %s\r\n", topic, payload);
    }
    else
    {
        fprintf(stderr, "Failed to publish file data. Return code: %d\n", rc);
    }
}

// Function to handle program termination signals
void handle_termination(int signum)
{
    printf("\nReceived termination signal. Cleaning up resources...\n");

    // Cleanup resources
    MQTTClient_destroy(&client);
    mraa_i2c_stop(i2c);
    mraa_uart_stop(uart);

    exit(0);
}	

// Function to read sensor values
void read_sensor_values(float *temperature, float *humidity)
{
    uint8_t data[6];
    mraa_i2c_write_byte(i2c, AHT25_MEASURE_CMD);

    // Delay for measurement
    usleep(1000); // Delay for 100 milliseconds

    mraa_i2c_read_bytes_data(i2c, 0x00, data, 6);

    *humidity = ((float)((data[1] << 12) | (data[2] << 4) | (data[3] >> 4))) / 1048576.0 * 100.0;
    *temperature = ((float)(((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5])) / 1048576.0 * 200.0 - 50.0;
}

int main()
{

   // Set up signal handler for program termination signals
    signal(SIGINT, handle_termination);
    // MQTT initialization
    MQTTClient_create(&client, MQTT_ADDRESS, MQTT_CLIENTID, MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;
    conn_opts.username = ACCESS_TOKEN;

    if (MQTTClient_connect(client, &conn_opts) != MQTTCLIENT_SUCCESS)
    {
        fprintf(stderr, "Failed to connect to MQTT server\n");
        return -1;
    }

    // Initialize I2C
    i2c = mraa_i2c_init(0); // Use the default I2C bus#include <unistd.h>
    mraa_i2c_frequency(i2c, MRAA_I2C_STD);
    mraa_i2c_address(i2c, AHT25_ADDR);
    mraa_i2c_write_byte(i2c, AHT25_INIT_CMD);

    // Initialize UART
    uart = mraa_uart_init(0); // Use the default UART
    mraa_uart_set_baudrate(uart, 115200);
    mraa_uart_set_mode(uart, 8, MRAA_UART_PARITY_NONE, 1);
    mraa_uart_set_flowcontrol(uart, 0, 0);

    while (1)
    {
        float temperature, humidity;
        read_sensor_values(&temperature, &humidity);

        // Convert sensor data to JSON string
        char mqtt_payload[500];
        snprintf(mqtt_payload, sizeof(mqtt_payload), "{\"Humidity\": %.2f, \"Temperature\": %.2f}", humidity, temperature);

        // Publish data to MQTT
        publishToMQTT(MQTT_TOPIC, mqtt_payload);

         // Print information about the published data
        printf("Data published to MQTT - Topic: %s, Payload: %s\r\n", MQTT_TOPIC, mqtt_payload);

        // Sleep for 7 seconds
        sleep(7);
    }

    // Cleanup resources
    MQTTClient_destroy(&client);
    mraa_i2c_stop(i2c);
    mraa_uart_stop(uart);

    return 0;
}

