#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mosquitto.h>
#include <unistd.h>

#define ACCESS_TOKEN "4Iq0PdNohIDjA9cZSyhH"
#define BROKER_ADDRESS "phyclouds.com"
#define BROKER_PORT 1884
#define CLIENT_ID "iiscSmartSwitch"
#define TOPIC "v1/devices/me/telemetry"

struct mosquitto *mosq = NULL;

void on_connect(struct mosquitto *mosq, void *userdata, int rc) {
    if (rc == 0) {
        printf("Connected to broker\n");
    } else {
        fprintf(stderr, "Failed to connect to broker\n");
    }
}

void on_publish(struct mosquitto *mosq, void *userdata, int mid) {
    printf("Data published to ThingsBoard\n");
}

int main() {
    mosquitto_lib_init();

    mosq = mosquitto_new(CLIENT_ID, true, NULL);
    if (!mosq) {
        fprintf(stderr, "Error: Out of memory.\n");
        return 1;
    }

    mosquitto_username_pw_set(mosq, NULL, ACCESS_TOKEN);

    mosquitto_connect_callback_set(mosq, on_connect);
    mosquitto_publish_callback_set(mosq, on_publish);

    if (mosquitto_connect(mosq, BROKER_ADDRESS, BROKER_PORT, 60) != MOSQ_ERR_SUCCESS) {
        fprintf(stderr, "Unable to connect to the broker.\n");
        return 1;
    }

    while (true) {
        char payload[100];
        snprintf(payload, sizeof(payload), "{\"Humidity\": %d, \"Temperature\": %d}", 10, 20);

        int mid;
        mosquitto_publish(mosq, &mid, TOPIC, strlen(payload), payload, 0, false);

        printf("Please check LATEST TELEMETRY field of your device\n");
        printf("%s\n", payload);

        sleep(7);
    }

    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();

    return 0;
}

