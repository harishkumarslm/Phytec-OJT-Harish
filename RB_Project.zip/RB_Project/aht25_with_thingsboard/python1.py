import paho.mqtt.client as paho
import time
import json
import mraa

# Replace 'oDfyF7380QGAv49715CV' with the actual access token of your device
ACCESS_TOKEN = '4Iq0PdNohIDjA9cZSyhH'

broker = "phyclouds.com"  # host name
port = 1884  # data listening port

# I2C bus and device addresses
I2C_BUS = 1
AHT25_ADDR = 0x38

# I2C device object
I2C = mraa.I2c(I2C_BUS)
I2C.address(AHT25_ADDR)

# AHT25 commands
AHT25_INIT_CMD = 0xE1
AHT25_MEASURE_CMD = 0xAC

# Read the temperature and humidity values from the AHT25 sensor
def read_sensor_values():
    I2C.writeByte(AHT25_MEASURE_CMD)
    time.sleep(0.85)  # Some delay for measurement

    data = I2C.read(6)
    humidity = ((data[1] << 12) | (data[2] << 4) | (data[3] >> 4)) / 1048576.0 * 100.0
    temperature = ((data[3] & 0x0F) << 16 | (data[4] << 8) | data[5]) / 1048576.0 * 200.0 - 50.0

    return temperature, humidity

def on_publish(client, userdata, result):
    print("Data published to ThingsBoard\n")

def main():
    client = paho.Client("Env_Monitoring")
    client.on_publish = on_publish
    client.username_pw_set(ACCESS_TOKEN)
    client.connect(broker, port, keepalive=60)

    # Initialize the AHT25 sensor
    I2C.writeByte(AHT25_INIT_CMD)
    time.sleep(0.1)  # Some delay for initialization

    while True:
        # Read sensor values
        temperature, humidity = read_sensor_values()

        payload = {"humidity": humidity, "temperature": temperature}
        payload_str = json.dumps(payload)

        time.sleep(1)  # Adjust this delay as needed for your application

        # Publish data to ThingsBoard
        result = client.publish("v1/devices/me/telemetry", payload_str)
        time.sleep(1)  # Adjust this delay as needed for your application

if __name__ == "__main__":
    main()

