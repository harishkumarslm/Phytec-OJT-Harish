#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <sys/ioctl.h>
#include <linux/i2c-dev.h>

#define I2C_DEVICE_PATH "/dev/i2c-0"
#define AHT25_ADDR 0x38
#define AHT25_INIT_CMD 0xE1
#define AHT25_MEASURE_CMD 0xAC
#define UART_DEVICE_PATH "/dev/ttyS0"

void write_i2c_register(int i2c_fd, uint8_t reg, uint8_t value) {
    unsigned char data[2];
    data[0] = reg;
    data[1] = value;
    if (write(i2c_fd, data, 2) != 2) {
        perror("Error writing to I2C device");
        exit(EXIT_FAILURE);
    }
}

void read_i2c_bytes(int i2c_fd, uint8_t reg, uint8_t *data, int len) {
    if (write(i2c_fd, &reg, 1) != 1) {
        perror("Error writing to I2C device");
        exit(EXIT_FAILURE);
    }

    if (read(i2c_fd, data, len) != len) {
        perror("Error reading from I2C device");
        exit(EXIT_FAILURE);
    }
}

void read_sensor_values(float *temperature, float *humidity, int i2c_fd) {
    write_i2c_register(i2c_fd, AHT25_MEASURE_CMD, 0);

    usleep(300000);  // Add a delay of 30 milliseconds

    uint8_t data[6];
    read_i2c_bytes(i2c_fd, 0x00, data, 6);

    *humidity = ((float)((data[1] << 12) | (data[2] << 4) | (data[3] >> 4))) / 1048576.0 * 100.0;
    *temperature = ((float)(((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5])) / 1048576.0 * 200.0 - 50.0;
}

void write_uart(const char *data, int uart_fd) {
    if (write(uart_fd, data, strlen(data)) != strlen(data)) {
        perror("Error writing to UART device");
        exit(EXIT_FAILURE);
    }
}

int main() {
    int i2c_fd = open(I2C_DEVICE_PATH, O_RDWR);
    if (i2c_fd == -1) {
        perror("Error opening I2C device");
        exit(EXIT_FAILURE);
    }

    if (ioctl(i2c_fd, I2C_SLAVE, AHT25_ADDR) == -1) {
        perror("Error setting I2C slave address");
        close(i2c_fd);
        exit(EXIT_FAILURE);
    }

    int uart_fd = open(UART_DEVICE_PATH, O_WRONLY);
    if (uart_fd == -1) {
        perror("Error opening UART device");
        close(i2c_fd);
        exit(EXIT_FAILURE);
    }

    write_i2c_register(i2c_fd, 0x00, AHT25_INIT_CMD);

    while (1) {
        float temperature, humidity;
        read_sensor_values(&temperature, &humidity, i2c_fd);

        char uart_data[50];
        snprintf(uart_data, sizeof(uart_data), "Temperature=%.2f\r\n", temperature);
        write_uart(uart_data, uart_fd);

        usleep(1000000);

        snprintf(uart_data, sizeof(uart_data), "Humidity=%.2f\r\n", humidity);
        write_uart(uart_data, uart_fd);

        usleep(1000000);
    }

    close(i2c_fd);
    close(uart_fd);

    return 0;
}
	
