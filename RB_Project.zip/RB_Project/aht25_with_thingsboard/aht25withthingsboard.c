
					AHT 25 WITH RUGGRDBOARD AND CONNECT WIHT THINGSBOARD MQTT BROKER

gothrough:

first check the sensor with stm32f446 re microcontroller and get the code for the sensor,
second check  the sensor with the ruggedboard a5d2x using i2c pheripheral to check the interfacing the sensor
