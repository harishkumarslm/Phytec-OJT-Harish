#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdint.h>
#include <sys/ioctl.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <stdint.h>

#define GPIO_PATH "/sys/class/gpio"
#define GPIO_EXPORT_PATH "/sys/class/gpio/export"
#define GPIO_UNEXPORT_PATH "/sys/class/gpio/unexport"

#define GPIO_SDA 21  // Assuming GPIO 21 is PD21
#define GPIO_SCL 22  // Assuming GPIO 22 is PD22
#define AHT25_ADDR 0x38 // Address of the AHT25 sensor
#define AHT25_INIT_CMD 0xE1
#define AHT25_MEASURE_CMD 0xAC

// Function to export GPIO pins
void export_gpio(int pin) {
    int export_fd = open(GPIO_EXPORT_PATH, O_WRONLY);
    char pin_str[4];
    snprintf(pin_str, sizeof(pin_str), "%d", pin);
    write(export_fd, pin_str, strlen(pin_str));
    close(export_fd);
}

// Function to unexport GPIO pins
void unexport_gpio(int pin) {
    int unexport_fd = open(GPIO_UNEXPORT_PATH, O_WRONLY);
    char pin_str[4];
    snprintf(pin_str, sizeof(pin_str), "%d", pin);
    write(unexport_fd, pin_str, strlen(pin_str));
    close(unexport_fd);
}

// Function to set GPIO direction
void set_gpio_direction(int pin, const char *direction) {
    char gpio_direction_path[50];
    snprintf(gpio_direction_path, sizeof(gpio_direction_path), "%s/gpio%d/direction", GPIO_PATH, pin);
    int gpio_fd = open(gpio_direction_path, O_WRONLY);
    write(gpio_fd, direction, strlen(direction));
    close(gpio_fd);
}

// Function to read sensor values
void read_sensor_values(int i2c_fd, float *temperature, float *humidity) {
    uint8_t data[6];
    uint8_t cmd = AHT25_MEASURE_CMD;

    // Transmit command to the sensor
    if (write(i2c_fd, &cmd, 1) != 1) {
        perror("Error writing to I2C device");
        exit(EXIT_FAILURE);
    }


    usleep(100000); // Delay for measurement

    // Receive data from the sensor
    if (read(i2c_fd, data, sizeof(data)) != sizeof(data)) {
        perror("Error reading from I2C device");
        exit(EXIT_FAILURE);
    }

    *humidity = ((float)((data[1] << 12) | (data[2] << 4) | (data[3] >> 4))) / 1048576.0 * 100.0;
    *temperature = ((float)(((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5])) / 1048576.0 * 200.0 - 50.0;
}

int main(int argc, char *argv[]) {
    // Export GPIO pins
    export_gpio(GPIO_SDA);
    export_gpio(GPIO_SCL);

    // Set GPIO directions
    set_gpio_direction(GPIO_SDA, "out");
    set_gpio_direction(GPIO_SCL, "out");

    // Open I2C device file
    int i2c_fd;
    if ((i2c_fd = open("/dev/i2c-0", O_RDWR)) < 0) {
        perror("Error opening I2C device");
        exit(EXIT_FAILURE);
    }

    // Set the I2C slave address
    if (ioctl(i2c_fd, I2C_SLAVE, AHT25_ADDR) < 0) {
        perror("Error setting I2C slave address");
        close(i2c_fd);
        exit(EXIT_FAILURE);
    }

    // Set up GPIO pins
   

    float temperature, humidity;

    // Read sensor values
    read_sensor_values(i2c_fd, &temperature, &humidity);

    // Print temperature and humidity
    printf("Temperature: %.2f°C\n", temperature);
    printf("Humidity: %.2f%%\n", humidity);

    // Close I2C device file
    close(i2c_fd);

    // Unexport GPIO pins
    unexport_gpio(GPIO_SDA);
    unexport_gpio(GPIO_SCL);

    return 0;
}

