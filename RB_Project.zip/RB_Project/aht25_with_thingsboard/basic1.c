#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <MQTTClient.h>
#include <unistd.h>

#define ACCESS_TOKEN "4Iq0PdNohIDjA9cZSyhH"
#define DEVICE_ID "a62f41b0-aaed-11ee-ae74-db5ae19db63f"
#define BROKER "phyclouds.com"
#define PORT 1884

void on_publish(void* context, MQTTClient_deliveryToken dt) {
    printf("Data published to ThingsBoard\n");
}

int main(int argc, char* argv[]) {
    MQTTClient client;
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    MQTTClient_deliveryToken token;

    char payload[256];

    MQTTClient_create(&client, BROKER, DEVICE_ID, MQTTCLIENT_PERSISTENCE_NONE, NULL);

    conn_opts.username = ACCESS_TOKEN;
    conn_opts.keepAliveInterval = 60;

    if (MQTTClient_connect(client, &conn_opts) != MQTTCLIENT_SUCCESS) {
        fprintf(stderr, "Failed to connect to the broker\n");
        return EXIT_FAILURE;
    }

    while (1) {
        snprintf(payload, sizeof(payload), "{\"Humidity\": 20, \"Temperature\": 10,\"Timestamp\":1648738185}");

        pubmsg.payload = payload;
        pubmsg.payloadlen = strlen(payload);
        pubmsg.qos = 1;
        pubmsg.retained = 0;

        if (MQTTClient_publishMessage(client, "v1/devices/me/telemetry", &pubmsg, &token) != MQTTCLIENT_SUCCESS) {
            fprintf(stderr, "Failed to publish message\n");
        } else {
            printf("Please check LATEST TELEMETRY field of your device\n");
            printf("%s\n", payload);
        }

        usleep(7000000);  // Sleep for 7 seconds
    }

    MQTTClient_disconnect(client, 5000);
    MQTTClient_destroy(&client);

    return EXIT_SUCCESS;
}

