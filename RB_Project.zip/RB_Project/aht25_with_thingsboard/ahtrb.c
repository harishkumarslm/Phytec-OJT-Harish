#include "stdio.h"
#include "string.h"
#include "mraa/i2c.h"
#include "mraa/uart.h"
#include "unistd.h"

#define AHT25_ADDR 0x38 // Address of the AHT25 sensor
#define I2C_BUS 0

#define AHT25_INIT_CMD 0xE1
#define AHT25_MEASURE_CMD 0xAC

mraa_i2c_context i2c;
mraa_uart_context uart;

void read_sensor_values(float *temperature, float *humidity)
{
    uint8_t data[6];
    uint8_t cmd = AHT25_MEASURE_CMD;
    mraa_i2c_write_byte(i2c,AHT25_MEASURE_CMD);

    // Delay for measurement
    usleep(1000);  // Delay for 100 milliseconds

    mraa_i2c_read_bytes_data(i2c, 0x00,data, 6);

    *humidity = ((float)((data[1] << 12) | (data[2] << 4) | (data[3] >> 4))) / 1048576.0 * 100.0;
    *temperature = ((float)(((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5])) / 1048576.0 * 200.0 - 50.0;
}

int main()
{
    // Initialize I2C
    i2c = mraa_i2c_init(0); // Use the default I2C bus
    mraa_i2c_frequency(i2c, MRAA_I2C_STD);
    mraa_i2c_address(i2c, AHT25_ADDR);
    mraa_i2c_write_byte(i2c, AHT25_INIT_CMD);
    

    // Initialize UART
    uart = mraa_uart_init(0); // Use the default UART
    mraa_uart_set_baudrate(uart, 115200);
    mraa_uart_set_mode(uart,8,MRAA_UART_PARITY_NONE,1);
    mraa_uart_set_flowcontrol(uart,0,0);

    while (1)
    {
	float temperature, humidity;	 
        read_sensor_values(&temperature, &humidity);
	 

        
        printf( "Temperature=%.2f\r\n", temperature);
  //    mraa_uart_write(uart, temperature);
	usleep(10000);
        printf( "Humidity=%.2f\r\n", humidity);
 //     mraa_uart_write(uart, humidit );
        usleep(10000);  
    }

    // Cleanup
    mraa_i2c_stop(i2c);
    mraa_uart_stop(uart);


    return 0;
}

