#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>  // Add this line for uint8_t type
#include <sys/ioctl.h>  // Add this line for ioctl function
#include <linux/i2c-dev.h>  // Add this line for I2C_SLAVE constant
#include <errno.h>
#include <termios.h>
#include <unistd.h>

#define AHT25_ADDR 0x38 // Address of the AHT25 sensor
#define I2C_BUS "/dev/i2c-0"

#define AHT25_INIT_CMD 0xE1
#define AHT25_MEASURE_CMD 0xAC

int i2c_fd;
int fd;
int wlen,rdlen;
char buf[100];
int set_interface_attribs(int fd, int speed)
{
        struct termios tty;

        if (tcgetattr(fd, &tty) < 0) 
        {
                printf("Error from tcgetattr: %s\n", strerror(errno));
                return -1;
        }

        cfsetispeed(&tty, (speed_t)speed);
        tty.c_cflag |= (CLOCAL | CREAD);    /* ignore modem controls */
        tty.c_cflag &= ~CSIZE;
        tty.c_cflag |= CS8;         /* 8-bit characters */
        tty.c_cflag &= ~PARENB;     /* no parity bit */
        tty.c_cflag &= ~CSTOPB;     /* only need 1 stop bit */
        tty.c_cflag &= ~CRTSCTS;    /* no hardware flowcontrol */


        tty.c_iflag = IGNPAR;
        tty.c_lflag = 0;

        
        tty.c_cc[VMIN] = 1;
        tty.c_cc[VTIME] = 1;

        if (tcsetattr(fd, TCSANOW, &tty) != 0) 
        {
                printf("Error from tcsetattr: %s\n", strerror(errno));
                return -1;
        }
        return 0;
}
void write_i2c_register(uint8_t reg, uint8_t value) {
    uint8_t buf[2];
    buf[0] = reg;
    buf[1] = value;
    write(i2c_fd, buf, 2);
}

void read_i2c_registers(uint8_t reg, uint8_t *data, int length) {
    write(i2c_fd, &reg, 1);
    read(i2c_fd, data, length);
}

void read_sensor_values(float *temperature, float *humidity) {
    uint8_t data[6];
    uint8_t cmd = AHT25_MEASURE_CMD;

    write_i2c_register(0x00, cmd);

    // Delay for measurement
    usleep(1000);  // Delay for 100 milliseconds

    read_i2c_registers(0x00, data, 6);

    *humidity = ((float)((data[1] << 12) | (data[2] << 4) | (data[3] >> 4))) / 1048576.0 * 100.0;
    *temperature = ((float)(((data[3] & 0x0F) << 16) | (data[4] << 8) | data[5])) / 1048576.0 * 200.0 - 50.0;
}

void mqtt_data_send()
{
  char arr8[]= "CMD+MQTTPUB=v1/devices/me/telemetry,%.2f %.2f\r\n",temperature,humidity;
   printf("%s", arr8);
   wlen = write(fd, arr8, sizeof(arr8) - 1);
   sleep(3);
   rdlen = read(fd, buf, sizeof(buf) - 1); // Read data into the buffer
   buf[rdlen]='\0';
   printf("%s\n", buf);
   usleep(100000);
}
int main() {
    char buffer[128];
    float temperature, humidity;
    char *portname = "/dev/ttyS3";
    int fd;
    int wlen;
    int rdlen;
    int ret;

    char res[5];
    char arr1[] = "CMD+RESET\r\n"; 
    char arr2[] = "CMD+WIFIMODE=1\r\n";
    char arr3[] = "CMD+CONTOAP=\"SBCS.2.4.GHz\",\"SBCS@1234\"\r\n";  
    char arr4[] = "CMD+MQTTNETCFG=tcp://phyclouds.com,1884\r\n";
    char arr5[] = "CMD+MQTTCONCFG=3,4Iq0PdNohIDjA9cZSyhH,,,,,,,,,\r\n";
    char arr6[] = "CMD+MQTTSTART=1\r\n";
   char arr7[] = "CMD+MQTTSUB=v1/devices/me/telemetry\r\n";
    // char arr8[] = " \r\n";
  
    unsigned char buf[100];  
fd = open(portname, O_RDWR | O_NOCTTY | O_SYNC);
    if (fd < 0) 
    {
        printf("Error opening %s: %s\n", portname, strerror(errno));
        return -1;
    }
    set_interface_attribs(fd, B38400);
    // Initialize I2C
    i2c_fd = open(I2C_BUS, O_RDWR);
    if (i2c_fd < 0) {
        perror("Error opening I2C bus");
        exit(1);
    }

    if (ioctl(i2c_fd, I2C_SLAVE, AHT25_ADDR) < 0) {
        perror("Error setting I2C address");
        close(i2c_fd);
        exit(1);
    }
//send cmd+reset=0
    printf("%s", arr1);
    wlen = write(fd, arr1, sizeof(arr1) - 1);  
    sleep(3);
    rdlen = read(fd, buf, sizeof(buf));
    buf[rdlen]='\0';
    printf("%s\n",buf); 

    // Send CMD+WIFIMODE=1
    printf("%s", arr2);
    wlen = write(fd, arr2, sizeof(arr2) - 1);
    sleep(3);
    rdlen = read(fd, buf, sizeof(buf));
    buf[rdlen]='\0';
    printf("%s\n",buf);

    // Send CMD+CONTOAP
    printf("%s", arr3);
    wlen = write(fd, arr3, sizeof(arr3) - 1);
    sleep(3);
    rdlen = read(fd, buf, sizeof(buf));
    buf[rdlen]='\0';
    printf("%s\n", buf);
    
    printf("%s", arr4);
    wlen = write(fd, arr4, sizeof(arr4) - 1);
    sleep(3);
    rdlen = read(fd, buf, sizeof(buf));
    buf[rdlen]='\0';
    printf("%s\n", buf);
    
    printf("%s", arr5);
    wlen = write(fd, arr5, sizeof(arr5) - 1);
    sleep(3);
    rdlen = read(fd, buf, sizeof(buf));
    buf[rdlen]='\0';
    printf("%s\n", buf);

    printf("%s", arr6);
    wlen = write(fd, arr6, sizeof(arr6) - 1);
    sleep(3);
    rdlen = read(fd, buf, sizeof(buf));
    buf[rdlen]='\0';
    printf("%s\n", buf);
   
    printf("%s", arr7);
    wlen = write(fd, arr7, sizeof(arr7) - 1);
    sleep(3);
    rdlen = read(fd, buf, sizeof(buf));
    buf[rdlen]='\0';
    printf("%s\n", buf);
    
  // printf("%s", arr8);
   //wlen = write(fd, arr8, sizeof(arr8) - 1);
   //sleep(3);
   //rdlen = read(fd, buf, sizeof(buf) - 1); // Read data into the buffer
   //buf[rdlen]='\0';
   //printf("%s\n", buf);
   //usleep(100000);
    
//    wlen = write(fd , buf, sizeof(buf));
//   wlen = write(fd ,"CMD+MQTTPUB=base/state/centimeter,%s\r\n", buf);
//char buffer[100]; // Create a buffer to hold the formatted message
//char buf[100]="42";    // Create a buffer to store the value read

//int fd; // Your file descriptor
//set_interface_attribs(fd, B9600);
// Read data into the 'buf' buffer
    write_i2c_register(0x00, AHT25_INIT_CMD);
    char payload[100]; 
    while (1) {
        read_sensor_values(&temperature, &humidity);

        printf("Temperature=%.2f\r\n", temperature);
        usleep(1000000);
        printf("Humidity=%.2f\r\n", humidity);
        usleep(1000000);
        snprintf(payload, sizeof(payload), "CMD+MQTTPUB=v1/devices/me/telemetry,%.2f %.2f\r\n", temperature, humidity);
        rdlen = read(fd, buf, sizeof(buf));
        buf[rdlen] = '\0';
        printf("%s\n", buf);

        mqtt_data_send();    
        usleep(10000);  
}
       
    close(i2c_fd);
    close(fd);
    return 0;
}

