#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <math.h>
#include <errno.h>
#include <fcntl.h> 
#include <string.h>
#include <termios.h>

#define led 12
#define digitalPin 2
#define analogPin 01  // Assuming A0 is the analog pin

int digitalVal;
int v_input;

void pinMode(int pin, int mode) {
    // Define the pinMode function based on the requirements of the Rugged Board environment
    // You might need to replace this with the appropriate function or library for the Rugged Board
    printf("Setting pin %d to mode %d\n", pin, mode);
}

int digitalRead(int pin) {
    // Define the digitalRead function based on the requirements of the Rugged Board environment
    // You might need to replace this with the appropriate function or library for the Rugged Board
    printf("Reading from digital pin %d\n", pin);
    return 0;  // Replace with actual digital reading
}

int analogRead(int pin) {
    // Define the analogRead function based on the requirements of the Rugged Board environment
    // You might need to replace this with the appropriate function or library for the Rugged Board
    printf("Reading from analog pin %d\n", pin);
    return 0;  // Replace with actual analog reading
}

void digitalWrite(int pin, int value) {
    // Define the digitalWrite function based on the requirements of the Rugged Board environment
    // You might need to replace this with the appropriate function or library for the Rugged Board
    printf("Setting digital pin %d to %d\n", pin, value);
}

void setup() {
    pinMode(led, OUTPUT);
    pinMode(digitalPin, INPUT);
    pinMode(analogPin, INPUT);
}

void loop() {
    // Read the digital interface
    digitalVal = digitalRead(digitalPin);

    if (digitalVal == 1) {  // Assuming HIGH corresponds to 1
        digitalWrite(led, 1);  // Assuming HIGH corresponds to 1
    } else {
        digitalWrite(led, 0);  // Assuming LOW corresponds to 0
    }

    printf("Digital Value : %d\n", digitalVal);

    // Read the analog interface
    v_input = analogRead(analogPin);
    float b = 10000 * (1024.0 / (float)v_input - 1.0);
    float c = (1.0 / (0.001129148 + (0.000234125 * log(b)) + 0.0000000876741 * log(b) * log(b) * log(b))) - 273.15;

    printf("Temperature in Celsius: %.2f\n", c);
    sleep(2);  // Assuming delay(2000) corresponds to a 2-second delay
}

