#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <errno.h>
#define GPIO_TRIGGER "/sys/class/gpio/PD19/value"
#define GPIO_ECHO "/sys/class/gpio/PD20/value"


int echo_fd, trigger_fd;

void setup() {
    // Export GPIO pins
    int export_fd = open("/sys/class/gpio/export", O_WRONLY);
    write(export_fd, "115", 2);  // Trigger pin
    write(export_fd, "116", 2);  // Echo pin
    close(export_fd);

    // Set GPIO directions
    trigger_fd = open("/sys/class/gpio/PD19/direction", O_WRONLY);
    write(trigger_fd, "out", 3);
    close(trigger_fd);

    echo_fd = open("/sys/class/gpio/PD20/direction", O_WRONLY);
    write(echo_fd, "in", 2);
    close(echo_fd);
}


void loop() {
    char buffer[2];  // Declare buffer
    while (1) {
       
        // Wait for echo response
        struct timeval start_time, end_time;
        gettimeofday(&start_time, NULL);

        echo_fd = open(GPIO_ECHO, O_RDONLY);
        while (read(echo_fd, buffer, 1) ==1 && buffer[0] == '0');
        gettimeofday(&end_time, NULL);
        close(echo_fd);

        // Calculate distance
        double elapsed_time = ((end_time.tv_sec - start_time.tv_sec) * 1000000.0 +
                              (end_time.tv_usec -  start_time.tv_usec));
         double distance = (elapsed_time * (0.0343 / 2.0));  // Speed of sound is approximately 343 meters/second

        printf("Echo1: %u Distance: %.2f cm\r\n", (unsigned int)elapsed_time, distance);
        usleep(500000);  // Delay for stable readings
    }
}

int main() {
    // Setup GPIO and UART
    setup();
    // Run the main loop
    loop();

    // Cleanup (not shown in this example)
    // Ensure to close file descriptors and unexport GPIO pins
    // cleanup();

    return 0;
}
