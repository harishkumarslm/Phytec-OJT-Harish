#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include "mraa/gpio.h"
#include "sys/time.h"

#define GPIO_ECHO 115
#define GPIO_TRIGGER 116

mraa_gpio_context echo_pin, trigger_pin;

void setup() {
    // Initialize GPIO pins
    echo_pin = mraa_gpio_init(GPIO_ECHO);
    trigger_pin = mraa_gpio_init(GPIO_TRIGGER);

    // Set GPIO directions
    mraa_gpio_dir(echo_pin, MRAA_GPIO_IN);
    mraa_gpio_dir(trigger_pin, MRAA_GPIO_OUT);
}

void triggerPulse() {
    mraa_gpio_write(trigger_pin, 1);
    usleep(10);
    mraa_gpio_write(trigger_pin, 0);
}

void loop() {
    char buffer[2];  // Declare buffer
    while (1) {
        // Trigger pulse
        triggerPulse();

        // Wait for echo response
        struct timeval start_time, end_time;
        gettimeofday(&start_time, NULL);

        while (mraa_gpio_read(echo_pin) == 0);
        gettimeofday(&end_time, NULL);

        // Calculate distance
        double elapsed_time = (end_time.tv_sec - start_time.tv_sec) * 1000000.0 +
                              (end_time.tv_usec - start_time.tv_usec);
        int dis1 = elapsed_time * 0.0343 / 2.0;  // Speed of sound is approximately 343 meters/second

        printf("Echo1: %u Dis1: %d cm\r\n", (unsigned int)elapsed_time, dis1);
        usleep(500000);  // Delay for stable readings
    }
}

int main() {
    // Setup GPIO
    setup();

    // Run the main loop
    loop();

    // Cleanup
    mraa_gpio_close(echo_pin);
    mraa_gpio_close(trigger_pin);

    return 0;
}

