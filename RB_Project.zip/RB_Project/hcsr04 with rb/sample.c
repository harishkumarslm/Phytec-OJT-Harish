#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>

#define TRIGGER_PIN "/sys/class/gpio/PA13/value" // Replace with the actual GPIO pin for trigger
#define ECHO_PIN "/sys/class/gpio/PA12/value"    // Replace with the actual GPIO pin for echo

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

long long micros()
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    return ts.tv_sec * 1000000LL + ts.tv_nsec / 1000LL;
}

int writeToFile(const char *path, const char *value)
{
    int fd = open(path, O_WRONLY);
    if (fd == -1)
    {
        perror("Error opening file");
        return -1;
    }

    if (write(fd, value, strlen(value)) == -1)
    {
        perror("Error writing to file");
        close(fd);
        return -1;
    }

    close(fd);
    return 0;
}

int readDigitalValue(const char *pin)
{
    char value[2];
    int fd = open(pin, O_RDONLY);
    if (fd == -1)
    {
        perror("Error opening digital pin");
        return -1;
    }

    if (read(fd, value, sizeof(value)) == -1)
    {
        perror("Error reading from file");
        close(fd);
        return -1;
    }

    close(fd);

    // '1' indicates the presence of a signal (tilted), '0' indicates no signal)
    return (value[0] == '1');
}

float readUltrasonicDistance()
{
    // Activate the trigger pin (PA13)
    if (writeToFile(TRIGGER_PIN, "1") == -1)
        error("Error setting trigger GPIO pin");

    usleep(10); // Sleep for a short duration to trigger the ultrasonic sensor

    // Deactivate the trigger pin (PA13)
    if (writeToFile(TRIGGER_PIN, "0") == -1)
        error("Error setting trigger GPIO pin");

    // Wait for the echo pin (PA12) to go high
    while (!readDigitalValue(ECHO_PIN))
        ;

    long startTime = micros();

    // Wait for the echo pin (PA12) to go low
    while (readDigitalValue(ECHO_PIN))
        ;

    long travelTime = micros() - startTime;

    // Calculate distance in centimeters
    float distance = (float)travelTime * 0.0343 / 2.0; // Speed of sound is approximately 343 meters/second

    return distance;
}

int main()
{
    // Assuming GPIO pins are not exported, you might need to export them first
    if (writeToFile("/sys/class/gpio/export", "13") == -1)
        error("Error exporting trigger GPIO pin");

    if (writeToFile("/sys/class/gpio/export", "12") == -1)
        error("Error exporting echo GPIO pin");

    // Set the GPIO pins direction to in (for reading)
    if (writeToFile("/sys/class/gpio/gpio13/direction", "out") == -1)
        error("Error setting direction for trigger GPIO pin");

    if (writeToFile("/sys/class/gpio/gpio12/direction", "in") == -1)
        error("Error setting direction for echo GPIO pin");

    while (1)
    {
        // Read the object distance using the ultrasonic sensor
        float distance = readUltrasonicDistance();

        printf("Object Distance: %.2f cm\n", distance);

        // Adjust the sleep duration based on your sensor's update rate
        sleep(1); // Sleep for 1 second between readings
    }

    // Unexport GPIO pins before exiting
    if (writeToFile("/sys/class/gpio/unexport", "13") == -1)
        error("Error unexporting trigger GPIO pin");

    if (writeToFile("/sys/class/gpio/unexport", "12") == -1)
        error("Error unexporting echo GPIO pin");

    return 0;
}

