#include <mraa.hpp>
#include <mraa/gpio.hpp>
#include <unistd.h>
#include <iostream>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define TRIG_PIN 12  // PA12
#define ECHO_PIN 13  // PA13

#define MAX_DISTANCE 200  // Maximum distance to measure (in centimeters)

NewPing sonar(TRIG_PIN, ECHO_PIN, MAX_DISTANCE);  // Create a NewPing object

LiquidCrystal_I2C lcd(0x27, 16, 2);  // Change 0x27 to your LCD I2C address if different

void setup() {
    lcd.begin();
    lcd.backlight();
    lcd.print("Ultrasonic Sensor");
    lcd.setCursor(0, 1);
    lcd.print("By Bharath Pi");
}

void loop() {
    delay(100);

    unsigned int distance = sonar.ping_cm();

    // Display the distance on the LCD
    lcd.setCursor(0, 1);
    lcd.print("Distance: ");
    lcd.print(distance);
    lcd.print(" cm    ");
}

int main() {
    mraa::init();

    setup();

    while (true) {
        loop();
        usleep(100000);  // Sleep for 100 ms
    }

    mraa::deinit();

    return 0;
}

