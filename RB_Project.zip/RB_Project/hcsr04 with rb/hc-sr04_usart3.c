#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/time.h>

#define UART_PORT "/dev/ttyS3"  // Replace with the actual UART device file
#define BAUD_RATE B115200

void error(const char *msg) {
    perror(msg);
    exit(1);
}

void ultrasonicMeasurement(int uart_fd) {
    char buffer[50];
    struct timeval start_time, end_time;

    while (1) {
        // Send trigger pulse to ultrasonic sensor via UART
        write(uart_fd, "T", 1);

        // Wait for the echo pulse from ultrasonic sensor
        while (1) {
            int n = read(uart_fd, buffer, 1);
            if (n < 0) {
                error("Error reading");
            }

            // Check for the start of the echo pulse
            if (buffer[0] == 'E') {
                gettimeofday(&start_time, NULL);
                break;
            }
        }

        // Wait for the end of the echo pulse
        while (1) {
            int n = read(uart_fd, buffer, 1);
            if (n < 0) {
                error("Error reading");
            }

            // Check for the end of the echo pulse
            if (buffer[0] == 'F') {
                gettimeofday(&end_time, NULL);
                break;
            }
        }

        // Calculate distance based on the pulse width
        double elapsed_time = ((end_time.tv_sec - start_time.tv_sec) * 1000000.0 +
                               (end_time.tv_usec - start_time.tv_usec));
        double distance = (elapsed_time / 58.0);  // Distance in centimeters

        printf("Distance: %.2f cm\n", distance);

        // Delay for 5 seconds before the next reading
        sleep(5);
    }
}

int main() {
    // Setup UART
    int uart_fd = open(UART_PORT, O_RDWR | O_NOCTTY | O_SYNC);
    if (uart_fd < 0) {
        error("Error opening UART");
    }

    struct termios tty;
    if (tcgetattr(uart_fd, &tty) < 0) {
        error("Error from tcgetattr");
    }

    cfsetospeed(&tty, BAUD_RATE);  // Set the baud rate
    cfsetispeed(&tty, BAUD_RATE);

    tty.c_cflag |= (CLOCAL | CREAD);    // Ignore modem control lines, enable receiver
    tty.c_cflag &= ~CSIZE;             // Clear data size bits
    tty.c_cflag |= CS8;                // 8-bit data
    tty.c_cflag &= ~PARENB;            // No parity bit
    tty.c_cflag &= ~CSTOPB;            // 1 stop bit
    tty.c_cflag &= ~CRTSCTS;           // No hardware flow control

    tty.c_lflag = 0;                   // Non-canonical mode

    tty.c_cc[VMIN] = 1;                // Minimum number of characters to read
    tty.c_cc[VTIME] = 1;               // Time to wait for data (in tenths of a second)

    if (tcsetattr(uart_fd, TCSANOW, &tty) != 0) {
        error("Error from tcsetattr");
    }

    // Run ultrasonic measurement loop
    ultrasonicMeasurement(uart_fd);

    // Close UART
    close(uart_fd);

    return 0;
}

