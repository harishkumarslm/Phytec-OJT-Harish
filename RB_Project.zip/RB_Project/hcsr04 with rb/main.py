import mraa
import time

TRIGGER_PIN = 12  # PD19
ECHO_PIN = 13  # PD20

# Initialize GPIO pins
trigger_gpio = mraa.Gpio(TRIGGER_PIN)
echo_gpio = mraa.Gpio(ECHO_PIN)

# Set GPIO directions
trigger_gpio.dir(mraa.DIR_OUT)
echo_gpio.dir(mraa.DIR_IN)

def transmit_pulse():
    # Trigger the ultrasonic sensor
    trigger_gpio.write(1)
    time.sleep(0.00001)  # Wait for at least 10us (trigger pulse width)
    trigger_gpio.write(0)

def receive_pulse():
    # Wait for the echo to be received
    while echo_gpio.read() == 0:
        pulse_start_time = time.time()

    while echo_gpio.read() == 1:
        pulse_end_time = time.time()

    return pulse_start_time, pulse_end_time

def calculate_distance():
    transmit_pulse()
    pulse_start, pulse_end = receive_pulse()

    elapsed_time = pulse_end - pulse_start
    distance = elapsed_time * 34300 / 2  # Speed of sound is approximately 343 meters/second

    return distance

try:
    while True:
        # Ultrasonic sensor distance measurement
        distance_cm = calculate_distance()
        print("Distance: %.2f cm" % distance_cm)

        time.sleep(1)  # Adjust the sleep duration based on your sensor's update rate

except KeyboardInterrupt:
    # Cleanup GPIO pins on KeyboardInterrupt
    trigger_gpio.write(0)  # Ensure the trigger is low before cleanup
    trigger_gpio.close()
    echo_gpio.close()
    print("\nScript terminated by user. GPIO pins cleaned up.")

