#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <mraa.h>

#define TRIG_PIN 12
#define ECHO_PIN 13

int main() {
    mraa_init();

    mraa_gpio_context trigPin = mraa_gpio_init(TRIG_PIN);
    mraa_gpio_context echoPin = mraa_gpio_init(ECHO_PIN);

    mraa_gpio_dir(trigPin, MRAA_GPIO_OUT);
    mraa_gpio_dir(echoPin, MRAA_GPIO_IN);

    while (1) {
        mraa_gpio_write(trigPin, 0);
        usleep(10);

        mraa_gpio_write(trigPin, 1);
        usleep(10);
        mraa_gpio_write(trigPin, 0);
	usleep(10);
        while (mraa_gpio_read(echoPin) == 0);

        struct timeval startTime, stopTime;
        gettimeofday(&startTime, NULL);

        while (mraa_gpio_read(echoPin) == 1);

        gettimeofday(&stopTime, NULL);

        double elapsed = (stopTime.tv_sec - startTime.tv_sec) * 1000000.0 + (stopTime.tv_usec - startTime.tv_usec);
        double distance = (elapsed * 0.034) / 2;

        char distanceStr[20];
        sprintf(distanceStr, "Distance: %.2f cm\n", distance);
        write(STDOUT_FILENO, distanceStr, sizeof(distanceStr));

        usleep(300000);  // Wait for 300ms before measuring again
    }

    mraa_gpio_close(trigPin);
    mraa_gpio_close(echoPin);

    mraa_deinit();

    return 0;
}

