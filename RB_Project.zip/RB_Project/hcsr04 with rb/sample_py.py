import mraa
import time

# Set GPIO Pins
GPIO_TRIGGER = 12  # PA12
GPIO_ECHO = 13  # PA13

# Set the GPIO modes
mraa.init()

# Define the GPIO pins as output and input
trigger_pin = mraa.Gpio(GPIO_TRIGGER)
echo_pin = mraa.Gpio(GPIO_ECHO)
trigger_pin.dir(mraa.DIR_OUT)
echo_pin.dir(mraa.DIR_IN)

def distance():
    # Set trigger to high
    trigger_pin.write(1)
 
    # Set trigger after 0.01ms to low
    time.sleep(0.00001)
    trigger_pin.write(0)
 
    start_time = time.time()
    stop_time = time.time()
 
    # Save start time
    while echo_pin.read() == 0:
        start_time = time.time()
 
    # Save time of arrival
    while echo_pin.read() == 1:
        stop_time = time.time()
 
    # Time difference between start and arrival
    time_elapsed = stop_time - start_time
    
    # Multiply with the speed of sound (34300 cm/s)
    # and divide by 2, because it's a round trip
    distance = (time_elapsed * 34300) / 2
 
    return distance

if __name__ == '__main__':
    try:
        while True:
            dist = distance()
            print("Measured Distance = {:.2f} cm".format(dist))
            time.sleep(1)
 
    except KeyboardInterrupt:
        print("Measurement stopped by User")

