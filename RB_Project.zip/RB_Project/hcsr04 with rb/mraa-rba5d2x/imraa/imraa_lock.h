/*
 * Author: Brendan Le Foll <brendan.le.folL@intel.com>
 * Copyright (c) 2016 Intel Corporation.
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

void imraa_write_lockfile(const char* lock_file_location, const char* serialport);

