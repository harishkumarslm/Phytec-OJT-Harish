/*
 * Author: Brendan Le Foll <brendan.le.folL@intel.com>
 * Copyright (c) 2016 Intel Corporation.
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

void imraa_handle_IO(struct json_object* jobj);

