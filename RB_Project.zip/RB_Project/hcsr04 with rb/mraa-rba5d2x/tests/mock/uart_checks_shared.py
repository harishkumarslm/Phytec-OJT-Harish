#!/usr/bin/env python

# Author: Alex Tereschenko <alext.mkrs@gmail.com>
# Copyright (c) 2016 Alex Tereschenko.
#
# SPDX-License-Identifier: MIT

MRAA_UART_DEV_NUM = 0
# This one is defined in mock_board_uart.h
MOCK_UART_DATA_BYTE = 0x5A
